import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"

export default function HomePage() {
  const assetCategories = [
    { name: "Watches", img: "/asset-watch.png", href: "/assets-we-fund#watches" },
    { name: "Electronics", img: "/asset-electronics.png", href: "/assets-we-fund#electronics" },
    { name: "Jewelry", img: "/asset-jewelry.png", href: "/assets-we-fund#jewelry" },
    { name: "Handbags", img: "/asset-handbag.png", href: "/assets-we-fund#handbags" },
  ]

  return (
    <>
      {/* Hero Section */}
      <section className="container mx-auto py-16 md:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="flex flex-col items-start">
            <h1 className="font-serif text-5xl md:text-6xl font-bold text-dark leading-tight">
              Quick Cash for Your Valuables.
            </h1>
            <p className="mt-4 text-lg text-gray-600 max-w-lg">
              Get a fair cash offer for items worth $500-$10,000. We'll wire the money in as little as 24 hours, and you
              keep the option to buy your item back.
            </p>
            <div className="mt-8 flex gap-4">
              <Button
                size="lg"
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 py-6 text-base"
              >
                <Link href="/apply">Get My Offer</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="rounded-full px-8 py-6 text-base border-gray-300 bg-transparent"
              >
                <Link href="/how-it-works">See How It Works</Link>
              </Button>
            </div>
          </div>
          <div className="relative w-full h-[450px] rounded-lg overflow-hidden shadow-xl">
            <Image
              src="/hero-flatlay.png"
              alt="A collection of valuable items including a camera, watch, and handbag on a table."
              layout="fill"
              objectFit="cover"
              priority
            />
          </div>
        </div>
      </section>

      {/* 3-Step Process */}
      <section className="py-20 md:py-28 bg-secondary">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold">Get Funded in 3 Simple Steps</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <Image
                src="/process-step1.png"
                alt="Person taking a photo of their watch"
                width={300}
                height={200}
                className="rounded-lg shadow-md mx-auto"
              />
              <h3 className="font-bold text-xl mt-6">1. Get Your Offer</h3>
              <p className="text-gray-600 mt-2">
                Tell us about your item online. It takes 2 minutes and won't affect your credit.
              </p>
            </div>
            <div>
              <Image
                src="/process-step2.png"
                alt="A secure shipping box with a prepaid label"
                width={300}
                height={200}
                className="rounded-lg shadow-md mx-auto"
              />
              <h3 className="font-bold text-xl mt-6">2. Ship For Free</h3>
              <p className="text-gray-600 mt-2">
                We provide a prepaid, insured shipping label. Just pack your item and drop it off.
              </p>
            </div>
            <div>
              <Image
                src="/process-step3.png"
                alt="A smartphone showing a bank transfer notification"
                width={300}
                height={200}
                className="rounded-lg shadow-md mx-auto"
              />
              <h3 className="font-bold text-xl mt-6">3. Get Paid Fast</h3>
              <p className="text-gray-600 mt-2">
                Once our experts verify your item, we wire your cash advance immediately.
              </p>
            </div>
          </div>
          <div className="text-center mt-12">
            <Button asChild size="lg" variant="link" className="text-primary">
              <Link href="/how-it-works">Learn More About Our Process →</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Assets We Fund */}
      <section className="py-20 md:py-28" id="assets">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold">What Can You Send Us?</h2>
            <p className="mt-4 max-w-2xl mx-auto text-gray-600">
              We accept a wide range of valuables. If it has a resale value of $500 or more, we're interested.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {assetCategories.map((category) => (
              <Link href={category.href} key={category.name}>
                <Card className="overflow-hidden group border-gray-200 hover:shadow-xl transition-shadow">
                  <div className="relative h-60">
                    <Image
                      src={category.img || "/placeholder.svg"}
                      alt={category.name}
                      layout="fill"
                      objectFit="cover"
                      className="group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-lg">{category.name}</h3>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
          <div className="text-center mt-12">
            <Button
              asChild
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8"
            >
              <Link href="/assets-we-fund">See All Categories</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Why Vaultly */}
      <section className="py-20 md:py-28 bg-dark text-dark-foreground">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="font-serif text-4xl md:text-5xl font-bold">The Smart Way to Get Cash.</h2>
              <p className="mt-4 text-lg text-gray-400">
                Selling isn't your only option. A traditional loan isn't always right. Vaultly gives you a better
                choice.
              </p>
              <ul className="mt-8 space-y-4">
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                  <span className="font-medium">No Credit Checks. Ever.</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                  <span className="font-medium">Keep the right to get your item back.</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                  <span className="font-medium">Fast, confidential, and secure process.</span>
                </li>
              </ul>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <Image
                src="/why-vaultly-image.png"
                alt="A person looking thoughtfully at their valuable items on a desk"
                layout="fill"
                objectFit="cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 md:py-28">
        <div className="container mx-auto">
          <div className="relative rounded-lg bg-secondary p-12 md:p-20 text-center overflow-hidden">
            <h2 className="font-serif text-4xl md:text-5xl font-bold">Ready to Unlock Your Asset's Value?</h2>
            <p className="mt-4 max-w-xl mx-auto text-gray-600">
              Start your confidential quote today to see what your asset is worth. It's free and takes just a few
              minutes.
            </p>
            <Button
              size="lg"
              asChild
              className="mt-8 bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-10 py-7 text-lg"
            >
              <Link href="/apply">Start My Quote</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  )
}
